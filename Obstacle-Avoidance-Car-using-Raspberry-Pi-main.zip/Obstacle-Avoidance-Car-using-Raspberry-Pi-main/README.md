# Obstacle-Avoidance-Car-using-Raspberry-Pi
An Automatic car which moves autonomously without any external events avoiding all the obstacle in its path, yes we talking about Obstacle Avoiding Car. In this project, we have used Raspberry Pi and Motor driver to drive the Car and Ultrasonic sensor for detecting objects in the path of car.
